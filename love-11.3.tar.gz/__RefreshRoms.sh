#!/bin/bash

rm -rf  ~/RetroPie/roms/ports/Love2D/*
cd ~/RetroPie/roms/love2d/
#for each .love file in ~/RetroPie/roms/love2d/ a .sh launcher will be created in ~/RetroPie/roms/ports/Love2D/
for file in *.love ; do
  target="/home/pi/RetroPie/roms/ports/Love2D/$file.sh"
  touch "$target"
  echo "#!/bin/bash" >> "$target"
  echo "love ~/RetroPie/roms/love2d/$file" >> "$target"
  chmod +x "$target"
done
